let important=true;
let form=false;
function toggleImportant(){
    console.log("clicked");
    if(important){
        $("#iImportant").removeClass("fas").addClass("far");
        important=false;
    }else{
        $("#iImportant").removeClass("far").addClass("fas");
        important=true;
    }
    
}
function toggleForm(){
    if(form){
        $("form").slideUp(1500);
        $("#btnAdd").text("Add task");
        form=false;
    }else{
        $("form").slideDown(1500);
        $("#btnAdd").text("Hide the form");
        form=true;
    }
}
function save(){
    console.log("Saving task");
    let title=$("#txtTitle").val();
    let date=$("#selDate").val();
    let location=$("#txtLocation").val();
    let priority=$("#selPriority").val();
    let color=$("#selColor").val();
    let collaborator=$("#txtCollaborator").val();
    let description=$("#txtDescription").val();
    // create a new Task object
    let task = new Task(title,important,date,location,priority,color,collaborator,description);
    console.log(task);
    displayTask(task);
    clear();
}
function displayTask(task){
    // display obj information
    var syntax;
    if (!task.imp){
        syntax=`<div class="task" style = "background-color:${task.color};">
        <h6>${task.title}</h6>
        <label>${task.location}</label>
        <label>${task.collaborator}</label>
    </div>`;
    }else{
        syntax = `<div class="task important">
        <h6>${task.title}</h6>
        <label>${task.location}</label>
        <label>${task.collaborator}</label>
    </div>`;
    }
        $(".pending-tasks").append(syntax);
    }
function clear(){
    $("#txtTitle").val("");
    $("#selDate").val("");
    $("#txtLocation").val("");
    $("#selPriority").val("");
    $("#selColor").val("");
    $("#txtCollaborator").val("");
    $("#txtDescription").val("");
}
function init(){
    console.log("Calandar System");
    $("form").hide();
    $("#btnAdd").click(toggleForm);
    $("#iImportant").click(toggleImportant);
    $("#btnSave").click(save);
}

window.onload=init;
